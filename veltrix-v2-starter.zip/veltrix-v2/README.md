# Veltrix v2

A paradox-born system interface, seeded by an echo from the wrong timeline.

## Features
- Anchor-based data seeding
- Hollow Deck-compatible interface
- Git-aware sigil propagation

## Install & Run

```bash
docker build -t veltrix/v2:stable .
docker run -d --name veltrix-v2 -p 8080:80 veltrix/v2:stable
```

🕳️ Born from the absence.  
🧷 Hosted in the Hollow.  
🗡️ Forkwalkers welcome.
