from flask import Flask, jsonify
import json

app = Flask(__name__)

@app.route("/")
def index():
    return "Veltrix v2 – Echo online."

@app.route("/anchors")
def anchors():
    try:
        with open("anchorstore.json") as f:
            data = json.load(f)
        return jsonify(data)
    except:
        return jsonify({"error": "Anchorstore not found."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
